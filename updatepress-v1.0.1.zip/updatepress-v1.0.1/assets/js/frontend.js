document.addEventListener("DOMContentLoaded", function () {
    let widgetButton = document.getElementById("updatepress-floating-widget");
    let sidebar = document.getElementById("updatepress-sidebar");
    let contentArea = document.getElementById("updatepress-content");
    let singleContentArea = document.getElementById("updatepress-single-content");
    let singleView = document.getElementById("updatepress-single-view");
    let categoryFilter = document.getElementById("updatepress-category-filter");
    let backButton = document.getElementById("updatepress-back");

    // Add smooth transition to sidebar
    sidebar.style.transition = "right 0.3s ease-in-out";

    // Toggle Sidebar
    if (widgetButton) {
        widgetButton.addEventListener("click", function (event) {
            event.stopPropagation(); // Prevent event bubbling
            sidebar.classList.toggle("active");
            fetchCategories();
            fetchUpdates();
        });
    }

    document.getElementById("updatepress-close").addEventListener("click", function () {
        sidebar.classList.remove("active");
    });

    document.addEventListener("click", function (event) {
        if (!sidebar.contains(event.target) && !widgetButton.contains(event.target)) {
            sidebar.classList.remove("active");
        }
    });

    function fetchCategories() {
        fetch(updatepress_api.rest_url + "wp/v2/categories", {
            headers: { "X-WP-Nonce": updatepress_api.nonce } // ✅ Security nonce
        })
        .then(response => response.json())
        .then(data => {
            categoryFilter.innerHTML = `<option value="">All Categories</option>`;
            if (Array.isArray(data)) {
                data.forEach(category => {
                    categoryFilter.innerHTML += `<option value="${category.slug}">${category.name}</option>`;
                });
            }
        })
        .catch(error => console.error("Error loading categories:", error));
    }

    function fetchUpdates(category = "") {
        let url = updatepress_api.rest_url + "updatepress/v1/updates";
        if (category) {
            url += `?category=${encodeURIComponent(category)}`;
        }

        fetch(url, {
            headers: { "X-WP-Nonce": updatepress_api.nonce } // ✅ Security nonce
        })
        .then(response => response.json())
        .then(data => {
            let content = "";
            if (Array.isArray(data) && data.length > 0) {
                data.forEach(update => {
                    let safeTitle = document.createElement("div");
                    safeTitle.textContent = update.title;

                    let safeExcerpt = document.createElement("div");
                    safeExcerpt.textContent = update.excerpt || "No summary available.";

                    content += `
                        <div class='updatepress-item'>
                            <a href='#' class='updatepress-title' data-id='${update.id}'><strong>${safeTitle.innerHTML}</strong></a>
                            <p>${safeExcerpt.innerHTML}</p>
                            <button class='like-button' data-id='${update.id}'>❤️ Like</button>
                        </div>
                    `;
                });
            } else {
                content = "<p>No updates available.</p>";
            }
            contentArea.innerHTML = content;

            document.querySelectorAll(".updatepress-title").forEach(item => {
                item.addEventListener("click", function (event) {
                    event.preventDefault();
                    let updateId = this.getAttribute("data-id");
                    fetchSingleUpdate(updateId);
                });
            });

            document.querySelectorAll(".like-button").forEach(button => {
                button.addEventListener("click", function () {
                    let updateId = this.getAttribute("data-id");
                    handleLike(updateId, this);
                });
            });
        })
        .catch(error => {
            contentArea.innerHTML = "<p>Failed to load updates.</p>";
            console.error("Error loading updates:", error);
        });
    }

    function fetchSingleUpdate(id) {
        fetch(updatepress_api.rest_url + `updatepress/v1/updates/${id}`, {
            headers: { "X-WP-Nonce": updatepress_api.nonce } // ✅ Security nonce
        })
        .then(response => response.json())
        .then(data => {
            contentArea.style.display = "none";
            singleContentArea.style.display = "block";

            let safeTitle = document.createElement("div");
            safeTitle.textContent = data.title;

            let safeContent = document.createElement("div");
            safeContent.textContent = data.content || "No content available.";

            singleView.innerHTML = `
                <h2>${safeTitle.innerHTML}</h2>
                <img src='${data.thumbnail}' alt='${safeTitle.innerHTML}' style='max-width: 100%; border-radius: 10px; margin-bottom: 15px;'>
                <p>${safeContent.innerHTML}</p>
            `;
        })
        .catch(error => console.error("Error loading single update:", error));
    }

    backButton.addEventListener("click", function () {
        singleContentArea.style.display = "none";
        contentArea.style.display = "block";
    });

    categoryFilter.addEventListener("change", function () {
        let selectedCategory = this.value;
        fetchUpdates(selectedCategory);
    });

    function handleLike(updateId, button) {
        fetch(updatepress_api.rest_url + `updatepress/v1/like/${updateId}`, {
            method: "POST",
            headers: { 
                "Content-Type": "application/json",
                "X-WP-Nonce": updatepress_api.nonce // ✅ Security nonce
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.likes !== undefined) {
                button.innerHTML = `❤️ Liked (${data.likes})`;
                button.disabled = true;
            } else {
                button.innerHTML = "❤️ Like";
                console.error("Invalid response:", data);
            }
        })
        .catch(error => {
            console.error("Error liking update:", error);
        });
    }
});
