jQuery(document).ready(function ($) {
    console.log('UpdatePress Archive Page Loaded');

    // Example: Highlight items on hover
    $('.updatepress-item').hover(
        function () {
            $(this).css('background-color', '#eef');
        },
        function () {
            $(this).css('background-color', '#ffffff');
        }
    );
});
