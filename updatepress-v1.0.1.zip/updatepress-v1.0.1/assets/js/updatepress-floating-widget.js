document.addEventListener("DOMContentLoaded", function () {
    let widgetButton = document.createElement("div");
    widgetButton.id = "updatepress-floating-widget";
    widgetButton.innerHTML = "<span class='updatepress-icon'>&#128276;</span>";
    document.body.appendChild(widgetButton);

    let sidebar = document.createElement("div");
    sidebar.id = "updatepress-sidebar";
    sidebar.style.position = "fixed";
    sidebar.style.right = "0";
    sidebar.style.top = "0";
    sidebar.style.width = "350px";
    sidebar.style.height = "100vh";
    sidebar.style.background = "#fff";
    sidebar.style.boxShadow = "-4px 0 8px rgba(0, 0, 0, 0.2)";
    sidebar.style.overflowY = "auto";
    sidebar.style.display = "none";
    sidebar.style.paddingBottom = "40px"; // Ensure space for footer

    sidebar.innerHTML = `
        <div id='updatepress-sidebar-header' style='padding: 10px; display: flex; flex-direction: column; gap: 8px;'>
            <span style='font-size: 16px; font-weight: bold;'>Latest Updates</span>
            <select id='updatepress-category-filter' style='width: 100%; max-width: 180px; padding: 5px; font-size: 12px;'>
                <option value="">All Categories</option>
            </select>
            <span id='updatepress-close' style='position: absolute; top: 10px; right: 10px; cursor: pointer;'>&times;</span>
        </div>
        <div id='updatepress-content'>
            <div class='updatepress-loader'>Loading updates...</div>
        </div>
        <div id='updatepress-single-content' style='display: none; padding: 15px;'>
            <button id='updatepress-back'>&larr; Back</button>
            <div id='updatepress-single-view' style='margin-top: 10px; padding: 10px; background: #f9f9f9; border-radius: 8px; box-shadow: 0 2px 5px rgba(44, 44, 44, 0.1);'>
                <h2 style='font-size: 20px; color: #003852; margin-bottom: 10px;'></h2>
                <p style='font-size: 14px; color: #333; line-height: 1.6;'></p>
            </div>
        </div>
        <div id='updatepress-footer' style='position: fixed; bottom: 0; right: 0; width: 350px; background: #0056b3; color: white; text-align: center; padding: 10px 0; font-size: 10px;'>
            Made with ❤️ by <a href="https://7thskysoftware.com/" target="_blank" style="color: white; text-decoration: none;">7th Sky Softwares</a>
        </div>
    `;
    document.body.appendChild(sidebar);

    widgetButton.addEventListener("click", function () {
        sidebar.style.display = "block";
        fetchCategories();
        fetchUpdates();
    });

    document.getElementById("updatepress-close").addEventListener("click", function () {
        sidebar.style.display = "none";
    });

    function fetchCategories() {
        fetch("/wp-json/wp/v2/updatepress_category")
            .then(response => response.json())
            .then(data => {
                let categoryFilter = document.getElementById("updatepress-category-filter");
                categoryFilter.innerHTML = `<option value="">All Categories</option>`;
                data.forEach(category => {
                    categoryFilter.innerHTML += `<option value="${category.slug}">${category.name}</option>`;
                });
            })
            .catch(error => console.error("Error loading categories:", error));
    }

    function fetchUpdates(category = "") {
        let url = "/wp-json/updatepress/v1/updates";
        if (category) {
            url += `?category=${category}`;
        }

        fetch(url)
            .then(response => response.json())
            .then(data => {
                let content = "";
                if (Array.isArray(data) && data.length > 0) {
                    data.forEach(update => {
                        let text = update.content.split(" ").slice(0, 40).join(" ") + "...";
                        content += `
                            <div class='updatepress-item'>
                                <a href='#' class='updatepress-title' data-id='${update.id}'><strong>${update.title}</strong></a>
                                <p>${text}</p>
                            </div>
                        `;
                    });
                } else {
                    content = "<p>No updates available.</p>";
                }
                document.getElementById("updatepress-content").innerHTML = content;

                document.querySelectorAll(".updatepress-title").forEach(item => {
                    item.addEventListener("click", function (event) {
                        event.preventDefault();
                        let updateId = this.getAttribute("data-id");
                        fetchSingleUpdate(updateId);
                    });
                });
            })
            .catch(error => {
                document.getElementById("updatepress-content").innerHTML = "<p>Failed to load updates.</p>";
                console.error("Error loading updates:", error);
            });
    }

    function fetchSingleUpdate(id) {
        fetch(`/wp-json/updatepress/v1/updates/${id}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById("updatepress-content").style.display = "none";
                document.getElementById("updatepress-single-content").style.display = "block";
                document.getElementById("updatepress-single-view").innerHTML = `
                    <h2 style='font-size: 20px; color: #003852; margin-bottom: 10px;'>${data.title}</h2>
                    <p style='font-size: 14px; color: #333; line-height: 1.6;'>${data.content}</p>
                `;
            })
            .catch(error => console.error("Error loading single update:", error));
    }

    document.getElementById("updatepress-back").addEventListener("click", function () {
        document.getElementById("updatepress-single-content").style.display = "none";
        document.getElementById("updatepress-content").style.display = "block";
    });

    document.getElementById("updatepress-category-filter").addEventListener("change", function () {
        let selectedCategory = this.value;
        fetchUpdates(selectedCategory);
    });
});
