jQuery(document).ready(function ($) {
    $.ajax({
        url: updatepress_api.rest_url,
        method: 'GET',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-WP-Nonce', updatepress_api.nonce); // ✅ Added security nonce
        },
        success: function (data) {
            let updateList = '';

            if (data.length > 0) {
                data.forEach(update => {
                    let safeTitle = $('<div>').text(update.title).html(); // ✅ XSS Protection
                    updateList += `<li><a href="${update.link}">${safeTitle}</a></li>`;
                });
            } else {
                updateList = '<p>No updates available.</p>'; // ✅ Added fallback for empty response
            }

            $('.updatepress-list').html(updateList);
        },
        error: function () {
            $('.updatepress-list').html('<p>Failed to load updates.</p>');
        }
    });
});
