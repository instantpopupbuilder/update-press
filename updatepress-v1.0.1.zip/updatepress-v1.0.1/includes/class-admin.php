<?php
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

class UpdatePress_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_enqueue_scripts', array($this, 'conditionally_enqueue_widget'));
        add_action('wp_footer', array($this, 'conditionally_output_widget_html'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_styles')); // ✅ Correctly enqueued admin styles
    }

    public function register_menu() {
        add_submenu_page(
            'edit.php?post_type=updatepress',
            __('Settings', 'updatepress'),
            __('Settings', 'updatepress'),
            'manage_options',
            'updatepress-settings',
            array($this, 'settings_page')
        );
    }

    public function register_settings() {
        register_setting('updatepress_settings_group', 'updatepress_floating_widget', 'sanitize_text_field');
        add_settings_section('updatepress_main_section', __('Main Settings', 'updatepress'), null, 'updatepress-settings');
        add_settings_field(
            'updatepress_floating_widget',
            __('Enable Floating Widget', 'updatepress'),
            array($this, 'floating_widget_callback'),
            'updatepress-settings',
            'updatepress_main_section'
        );
    }

    public function floating_widget_callback() {
        $option = get_option('updatepress_floating_widget', 'yes');
    
        echo '<label class="switch">
                <input type="checkbox" name="updatepress_floating_widget" value="yes" ' . checked('yes', $option, false) . '>
                <span class="slider round"></span>
              </label>';
    }

    public function enqueue_admin_styles() {
        // Register and enqueue styles only in admin panel
        wp_register_style(
            'updatepress-admin-style',
            UPDATEPRESS_URL . 'assets/css/admin-style.css',
            array(),
            UPDATEPRESS_VERSION
        );
        wp_enqueue_style('updatepress-admin-style');
    }

    public function settings_page() {
        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('UpdatePress Settings', 'updatepress') . '</h1>';
        echo '<form method="post" action="options.php">';
        settings_fields('updatepress_settings_group');
        do_settings_sections('updatepress-settings');
        submit_button();
        echo '</form>';
        echo '</div>';
    }

    public function conditionally_enqueue_widget() {
        $option = get_option('updatepress_floating_widget', 'yes');
        if ($option === 'yes') {
            // Register and enqueue widget styles & scripts
            wp_register_script(
                'updatepress-floating-widget-script',
                UPDATEPRESS_URL . 'assets/js/updatepress-floating-widget.js',
                array('jquery'),
                UPDATEPRESS_VERSION,
                true
            );
            wp_enqueue_script('updatepress-floating-widget-script');

            wp_register_style(
                'updatepress-floating-widget-style',
                UPDATEPRESS_URL . 'assets/css/updatepress-floating-widget.css',
                array(),
                filemtime(UPDATEPRESS_PATH . 'assets/css/updatepress-floating-widget.css') // ✅ Dynamic cache busting
            );
            wp_enqueue_style('updatepress-floating-widget-style');
        }
    }

    public function conditionally_output_widget_html() {
        $option = get_option('updatepress_floating_widget', 'yes');
        if ($option === 'yes') {
            echo '<div id="updatepress-floating-widget">
                    <span class="updatepress-icon">&#128276;</span>
                  </div>';
        }
    }
}

// Initialize Admin Class
new UpdatePress_Admin();
