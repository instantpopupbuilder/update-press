<?php
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

class UpdatePress_CPT {
    public static function register_cpt() {
        $labels = array(
            'name'               => __('Updates', 'updatepress'),
            'singular_name'      => __('Update', 'updatepress'),
            'menu_name'          => __('UpdatePress', 'updatepress'),
            'add_new'            => __('Add New Update', 'updatepress'),
            'add_new_item'       => __('Add New Update', 'updatepress'),
            'edit_item'          => __('Edit Update', 'updatepress'),
            'new_item'           => __('New Update', 'updatepress'),
            'view_item'          => __('View Update', 'updatepress'),
            'search_items'       => __('Search Updates', 'updatepress'),
            'not_found'          => __('No updates found.', 'updatepress'),
            'not_found_in_trash' => __('No updates found in trash.', 'updatepress'),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'menu_position'      => 25,
            'menu_icon'          => 'dashicons-megaphone',
            'supports'           => array('title', 'editor', 'thumbnail', 'excerpt'),
            'has_archive'        => true,
            'rewrite'            => array('slug' => 'updates'),
            'show_in_rest'       => true,
        );

        register_post_type('updatepress', $args);
    }

    // Enqueue Admin Scripts & Styles
    public static function enqueue_admin_assets($hook) {
        // Load only on Edit and Add New screens for the 'updatepress' post type
        if ($hook === 'post.php' || $hook === 'post-new.php') {
            $screen = get_current_screen();
            if ($screen && $screen->post_type === 'updatepress') {
                // Register and enqueue styles
                wp_register_style(
                    'updatepress-admin-style',
                    UPDATEPRESS_URL . 'assets/css/updatepress-admin.css',
                    array(),
                    UPDATEPRESS_VERSION
                );
                wp_enqueue_style('updatepress-admin-style');

                // Register and enqueue scripts
                wp_register_script(
                    'updatepress-admin-script',
                    UPDATEPRESS_URL . 'assets/js/updatepress-admin.js',
                    array('jquery'),
                    UPDATEPRESS_VERSION,
                    true
                );
                wp_enqueue_script('updatepress-admin-script');
            }
        }
    }
}

// Hook into WordPress
add_action('init', array('UpdatePress_CPT', 'register_cpt'));
add_action('admin_enqueue_scripts', array('UpdatePress_CPT', 'enqueue_admin_assets'));
