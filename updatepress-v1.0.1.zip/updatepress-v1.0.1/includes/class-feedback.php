<?php
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}