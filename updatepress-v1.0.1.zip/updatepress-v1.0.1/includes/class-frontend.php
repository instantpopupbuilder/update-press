<?php
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

class UpdatePress_Frontend {
    public function __construct() {
        add_shortcode('updatepress', array($this, 'display_updates'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
    }

    // Enqueue Styles & Scripts for Frontend
    public function enqueue_frontend_assets() {
        // Ensure that get_post_field() is used safely
        $post_content = get_post_field('post_content', get_queried_object_id());

        if (!is_singular() || (empty($post_content) || strpos($post_content, '[updatepress]') === false)) {
            return; // Load assets only if the shortcode is present in the content
        }

        // Register and enqueue styles
        wp_register_style(
            'updatepress-frontend-style',
            UPDATEPRESS_URL . 'assets/css/updatepress-frontend.css',
            array(),
            UPDATEPRESS_VERSION
        );
        wp_enqueue_style('updatepress-frontend-style');

        // Register and enqueue scripts
        wp_register_script(
            'updatepress-frontend-script',
            UPDATEPRESS_URL . 'assets/js/updatepress-frontend.js',
            array('jquery'),
            UPDATEPRESS_VERSION,
            true
        );
        wp_enqueue_script('updatepress-frontend-script');
    }

    public function display_updates($atts) {
        $atts = shortcode_atts(array('limit' => 5), $atts, 'updatepress');

        $query = new WP_Query(array(
            'post_type'      => 'updatepress',
            'posts_per_page' => absint($atts['limit']),
            'orderby'        => 'date',
            'order'          => 'DESC',
        ));

        ob_start();

        if ($query->have_posts()) {
            echo '<ul class="updatepress-list">';
            while ($query->have_posts()) {
                $query->the_post();
                echo '<li><a href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a></li>';
            }
            echo '</ul>';
        } else {
            echo '<p>' . esc_html__('No updates found.', 'updatepress') . '</p>';
        }

        wp_reset_postdata();
        return ob_get_clean();
    }
}

// Initialize Frontend Class
new UpdatePress_Frontend();
