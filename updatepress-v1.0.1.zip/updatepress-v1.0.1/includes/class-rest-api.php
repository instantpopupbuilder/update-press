<?php
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

class UpdatePress_REST_API {
    public function __construct() {
        add_action('init', array($this, 'register_updatepress_category')); // Register custom taxonomy
        add_action('rest_api_init', array($this, 'register_api_routes'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_rest_api_scripts'));
    }

    public function register_updatepress_category() {
        register_taxonomy('updatepress_category', 'updatepress', array(
            'label' => __('Update Categories', 'updatepress'),
            'rewrite' => array('slug' => 'update-category'),
            'hierarchical' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
        ));
    }

    public function register_api_routes() {
        // Publicly available published updates
        register_rest_route('updatepress/v1', '/updates', array(
            'methods'  => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_updates'),
            'permission_callback' => '__return_true', // Allow public access
        ));

        // Single update: Public for published, restricted for unpublished
        register_rest_route('updatepress/v1', '/updates/(?P<id>\d+)', array(
            'methods'  => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_single_update'),
            'permission_callback' => '__return_true', // Allow public access but restrict unpublished content inside callback
        ));
    }

    public function enqueue_rest_api_scripts() {
        if (!is_singular() || !has_shortcode(get_post_field('post_content', get_queried_object_id()), 'updatepress')) {
            return; // Load only if shortcode is present
        }

        // Register and enqueue scripts properly
        wp_register_script(
            'updatepress-rest-api-script',
            UPDATEPRESS_URL . 'assets/js/updatepress-rest-api.js',
            array('jquery'),
            UPDATEPRESS_VERSION,
            true
        );
        wp_enqueue_script('updatepress-rest-api-script');

        // Pass REST API URL & nonce to JavaScript
        wp_localize_script('updatepress-rest-api-script', 'updatepress_api', array(
            'rest_url' => esc_url_raw(rest_url('updatepress/v1/updates')),
            'nonce'    => wp_create_nonce('wp_rest') // Added nonce for security
        ));
    }

    public function get_updates($request) {
        $category = $request->get_param('category');

        $args = array(
            'post_type'      => 'updatepress',
            'posts_per_page' => 5,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'post_status'    => 'publish', // Only return published updates
        );

        if ($category) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'updatepress_category',
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field($category),
                ),
            );
        }

        $query = new WP_Query($args);
        $updates = array();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $categories = get_the_terms(get_the_ID(), 'updatepress_category');
                $category_names = $categories ? wp_list_pluck($categories, 'slug') : [];
                
                $updates[] = array(
                    'id'      => get_the_ID(),
                    'title'   => get_the_title(),
                    'content' => apply_filters('the_content', get_the_content()),
                    'excerpt' => get_the_excerpt(),
                    'date'    => get_the_date('c'),
                    'link'    => get_permalink(),
                    'categories' => $category_names,
                    'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
                );
            }
        }
        wp_reset_postdata();
        return rest_ensure_response($updates);
    }

    public function get_single_update($request) {
        $post_id = $request['id'];
        $post = get_post($post_id);

        if (!$post || $post->post_type !== 'updatepress') {
            return new WP_Error('not_found', __('Update not found', 'updatepress'), array('status' => 404));
        }

        // Public access only if the update is published
        if ($post->post_status !== 'publish' && !is_user_logged_in()) {
            return new WP_Error('unauthorized', __('You are not authorized to view this update.', 'updatepress'), array('status' => 403));
        }

        $categories = get_the_terms($post->ID, 'updatepress_category');
        $category_names = $categories ? wp_list_pluck($categories, 'slug') : [];
        
        return rest_ensure_response(array(
            'id'      => $post->ID,
            'title'   => get_the_title($post),
            'content' => apply_filters('the_content', $post->post_content),
            'excerpt' => get_the_excerpt($post),
            'date'    => get_the_date('c', $post),
            'categories' => $category_names,
            'thumbnail' => get_the_post_thumbnail_url($post->ID, 'medium'),
        ));
    }
}

// Initialize REST API Class
new UpdatePress_REST_API();
