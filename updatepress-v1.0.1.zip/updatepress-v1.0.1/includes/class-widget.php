<?php
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

class UpdatePress_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'updatepress_widget',
            __('UpdatePress Widget', 'updatepress'),
            array('description' => __('Displays recent updates from UpdatePress', 'updatepress'))
        );
    }

    // Enqueue widget-specific assets
    public static function enqueue_widget_assets() {
        if (!is_active_widget(false, false, 'updatepress_widget', true)) {
            return; // Only load assets if the widget is active
        }

        // Register and enqueue styles
        wp_register_style(
            'updatepress-widget-style',
            UPDATEPRESS_URL . 'assets/css/updatepress-widget.css',
            array(),
            UPDATEPRESS_VERSION
        );
        wp_enqueue_style('updatepress-widget-style');

        // Register and enqueue scripts
        wp_register_script(
            'updatepress-widget-script',
            UPDATEPRESS_URL . 'assets/js/updatepress-widget.js',
            array('jquery'),
            UPDATEPRESS_VERSION,
            true
        );
        wp_enqueue_script('updatepress-widget-script');
    }

    public function widget($args, $instance) {
        echo wp_kses_post($args['before_widget']);
        if (!empty($instance['title'])) {
            echo wp_kses_post($args['before_title']) . esc_html(apply_filters('widget_title', $instance['title'])) . wp_kses_post($args['after_title']);
        }
        
        $query = new WP_Query(array(
            'post_type'      => 'updatepress',
            'posts_per_page' => !empty($instance['count']) ? $instance['count'] : 5,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ));
        
        if ($query->have_posts()) {
            echo '<ul class="updatepress-widget-list">';
            while ($query->have_posts()) {
                $query->the_post();
                echo '<li><a href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a></li>';
            }
            echo '</ul>';
        } else {
            echo '<p>' . esc_html__('No updates found.', 'updatepress') . '</p>';
        }
        wp_reset_postdata();
        
        echo wp_kses_post($args['after_widget']);
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : __('Recent Updates', 'updatepress');
        $count = !empty($instance['count']) ? $instance['count'] : 5;
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'updatepress'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('count')); ?>"><?php esc_html_e('Number of Updates:', 'updatepress'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('count')); ?>" name="<?php echo esc_attr($this->get_field_name('count')); ?>" type="number" value="<?php echo esc_attr($count); ?>" min="1">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['count'] = (!empty($new_instance['count'])) ? absint($new_instance['count']) : 5;
        return $instance;
    }
}

// Register the widget and enqueue assets correctly
function updatepress_register_custom_widget() { // Updated function name
    register_widget('UpdatePress_Widget');
}
add_action('widgets_init', 'updatepress_register_custom_widget'); // Updated reference

// Ensure widget scripts and styles are enqueued properly
add_action('wp_enqueue_scripts', array('UpdatePress_Widget', 'enqueue_widget_assets'));