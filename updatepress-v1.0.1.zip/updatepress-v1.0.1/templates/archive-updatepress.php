<?php
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

/**
 * Template Name: UpdatePress Archive
 * Template for displaying all updates in UpdatePress format.
 */

get_header(); 

// Enqueue styles & scripts for this template
function updatepress_archive_enqueue_assets() {
    if (is_post_type_archive('updatepress') || is_page_template('updatepress-archive.php')) {
        wp_register_style(
            'updatepress-archive-style',
            UPDATEPRESS_URL . 'assets/css/updatepress-archive.css',
            array(),
            UPDATEPRESS_VERSION
        );
        wp_enqueue_style('updatepress-archive-style');

        wp_register_script(
            'updatepress-archive-script',
            UPDATEPRESS_URL . 'assets/js/updatepress-archive.js',
            array('jquery'),
            UPDATEPRESS_VERSION,
            true
        );
        wp_enqueue_script('updatepress-archive-script');
    }
}

// Ensure function only runs once
if (!has_action('wp_enqueue_scripts', 'updatepress_archive_enqueue_assets')) {
    add_action('wp_enqueue_scripts', 'updatepress_archive_enqueue_assets');
}

?>

<div class="updatepress-archive-container">
    <header class="updatepress-header">
        <h1><?php esc_html_e('Latest Updates', 'updatepress'); ?></h1>
    </header>

    <div class="updatepress-archive-content">
        <?php if (have_posts()) : ?>
            <ul class="updatepress-list">
                <?php while (have_posts()) : the_post(); ?>
                    <li class="updatepress-item">
                        <span class="update-tag">Bug Fix</span>
                        <p class="updatepress-meta"> <?php echo get_the_date(); ?> </p>
                        <h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a></h2>
                        <p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20, '...' ) ); ?></p>
                    </li>
                <?php endwhile; ?>
            </ul>
            
            <div class="updatepress-pagination">
                <?php the_posts_pagination(); ?>
            </div>
        <?php else : ?>
            <p><?php esc_html_e('No updates found.', 'updatepress'); ?></p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
