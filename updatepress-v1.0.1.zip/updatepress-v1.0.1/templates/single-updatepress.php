<?php
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

/**
 * Template for displaying a single update.
 */

get_header(); 

// Enqueue styles & scripts for this template
function updatepress_single_enqueue_assets() {
    if (is_singular('updatepress')) {
        wp_register_style(
            'updatepress-single-style',
            UPDATEPRESS_URL . 'assets/css/updatepress-single.css',
            array(),
            UPDATEPRESS_VERSION
        );
        wp_enqueue_style('updatepress-single-style');

        wp_register_script(
            'updatepress-single-script',
            UPDATEPRESS_URL . 'assets/js/updatepress-single.js',
            array('jquery'),
            UPDATEPRESS_VERSION,
            true
        );
        wp_enqueue_script('updatepress-single-script');
    }
}

// Ensure the function only runs once
if (!has_action('wp_enqueue_scripts', 'updatepress_single_enqueue_assets')) {
    add_action('wp_enqueue_scripts', 'updatepress_single_enqueue_assets');
}

?>

<div class="updatepress-single-container">
    <article class="updatepress-single">
        <header class="updatepress-header">
            <h1><?php the_title(); ?></h1>
            <p class="updatepress-meta">Published on <?php echo get_the_date(); ?></p>
        </header>

        <div class="updatepress-content">
            <?php if (has_post_thumbnail()) : ?>
                <div class="updatepress-thumbnail">
                    <?php the_post_thumbnail('large'); ?>
                </div>
            <?php endif; ?>
            
            <?php the_content(); ?>
        </div>

        <footer class="updatepress-footer">
            <p><strong>Category:</strong> <?php the_category(', '); ?></p>
            <p><strong>Tags:</strong> <?php the_tags('', ', ', ''); ?></p>
        </footer>
    </article>

    <div class="updatepress-navigation">
        <div class="prev-update"><?php previous_post_link('%link', '&larr; Previous Update'); ?></div>
        <div class="next-update"><?php next_post_link('%link', 'Next Update &rarr;'); ?></div>
    </div>
</div>

<?php get_footer(); ?>
